/*---------------------------------------------------------------------------
	Help tabs. These show up in the help menu (F1).
---------------------------------------------------------------------------*/
UBR.AddHelpTab("How to Play",
	[[Players are dropped at random in the sky. Activate your parachute and loot weaponry, munitions, and more. The last player alive wins the game. The zone will shrink and move to random positions over time, confining people to a limited space.]]
)

UBR.AddHelpTab("Donate",
	[[Donate for (buy) admin on our website www.genericdarkrpserver.com

we have VAPES CSGO KNIVES PROSTITUTION AAAAAAA
mega VAPE 34.99 shekels]]
)