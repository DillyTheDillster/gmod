/*---------------------------------------------------------------------------
	Adding entities, the ones here are built in
---------------------------------------------------------------------------*/
UBR.AddEntity({
	class = "gas_can",
	rarity = 0.7
})

UBR.AddEntity({
	class = "energy_drink",
	rarity = 0.6
})

UBR.AddEntity({
	class = "first_aid",
	rarity = 0.3
})

UBR.AddEntity({
	class = "med_kit",
	rarity = 0.1
})

UBR.AddEntity({
	class = "painkillers",
	rarity = 0.6
})

UBR.AddEntity({
	class = "armor_pickup",
	rarity = 0.6
})