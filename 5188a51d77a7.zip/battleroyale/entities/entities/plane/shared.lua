ENT.Type = "anim"
ENT.PrintName = "Plane"
ENT.Author = "Threebow"