return {
	title = "ultimit batel royel",
	in_safezone = "located in circle",
	out_of_safezone = "%im far from circle",
	cooldown = "heat cool off",
	starts_soon = "soon beginning game",
	waiting_for_plys = "waiting for slaves <%i/%i>",
	preparing = "creating bulets %is",
	final_circle = "last sphere",
	zone_shrinking = "circle smalling",
	shrinking_in = "shrink in %s",
	alive_count = "living",
	kill_count = "ded",
	speed = "%i minute pur hour",
	distance = "%i meter",
	activate_parachute = "press spacebar to activate ur gravity decreaser",
	tooltip_key = "e",

	drop_item = "put down",
	use_item = "utilize",
	pickup_item = "grab",
	vicinity = "close things",
	inventory = "ur stuff",
	weapons = "blam blams",
	using = "utilizing%s",
	use_time = "%i second",
	inventory_full = "too many stuffs",

	parachute_color = "colorize ur chute",
	submit = "send in",

	spec_health = "health points",
	spec_armor = "bullet blockers",
	spec_kills = "amount made ded",
	spec_lmb = "left maus",
	spec_rmb = "right maus",

	win = "winner winner turkey diner",

	zone_alert = "sphere start smalling in %is, will hurt in %is",
	ammo_tooltip = "%s < %i >",

	already_has_weapon = "u already have this blam blam",
	too_many_weapons = "drop some blam blams",

	below_100_health = "u must not be full health point to utilize",
	below_75_health = "u must be below 3/4 health point to utilize",
	must_be_in_vehicle = "only utilize in a vroom vroom skrrt",

	looting = "stealing",
	airdrop = "overwatch loot box",
	airdrop_spawned = "loot box been made up in da sky",
	already_being_looted = "dis already being stoln",

	jump_from_plane = "clik de use button to skydive with ur stolen tv"
}