return {
	title = "Donate $45 for admin www.genericdarkrpserver.com",
	in_safezone = "Donate $45 for admin www.genericdarkrpserver.com",
	out_of_safezone = "Donate $45 for admin www.genericdarkrpserver.com",
	cooldown = "Donate $45 for admin www.genericdarkrpserver.com",
	starts_soon = "Donate $45 for admin www.genericdarkrpserver.com",
	waiting_for_plys = "Donate $45 for admin www.genericdarkrpserver.com",
	preparing = "Donate $45 for admin www.genericdarkrpserver.com",
	final_circle = "Donate $45 for admin www.genericdarkrpserver.com",
	zone_shrinking = "Donate $45 for admin www.genericdarkrpserver.com",
	shrinking_in = "Donate $45 for admin www.genericdarkrpserver.com",
	alive_count = "Donate $45 for admin www.genericdarkrpserver.com",
	kill_count = "Donate $45 for admin www.genericdarkrpserver.com",
	speed = "Donate $45 for admin www.genericdarkrpserver.com",
	distance = "Donate $45 for admin www.genericdarkrpserver.com",
	activate_parachute = "Donate $45 for admin www.genericdarkrpserver.com",
	tooltip_key = "Donate $45 for admin www.genericdarkrpserver.com",

	drop_item = "Donate $45 for admin www.genericdarkrpserver.com",
	use_item = "Donate $45 for admin www.genericdarkrpserver.com",
	pickup_item = "Donate $45 for admin www.genericdarkrpserver.com",
	vicinity = "Donate $45 for admin www.genericdarkrpserver.com",
	inventory = "Donate $45 for admin www.genericdarkrpserver.com",
	weapons = "Donate $45 for admin www.genericdarkrpserver.com",
	using = "Donate $45 for admin www.genericdarkrpserver.com",
	use_time = "Donate $45 for admin www.genericdarkrpserver.com",
	inventory_full = "Donate $45 for admin www.genericdarkrpserver.com",

	parachute_color = "Donate $45 for admin www.genericdarkrpserver.com",
	submit = "Donate $45 for admin www.genericdarkrpserver.com",

	spec_health = "Donate $45 for admin www.genericdarkrpserver.com",
	spec_armor = "Donate $45 for admin www.genericdarkrpserver.com",
	spec_kills = "Donate $45 for admin www.genericdarkrpserver.com",
	spec_lmb = "Donate $45 for admin www.genericdarkrpserver.com",
	spec_rmb = "Donate $45 for admin www.genericdarkrpserver.com",

	win = "Donate $45 for admin www.genericdarkrpserver.com",

	zone_alert = "Donate $45 for admin www.genericdarkrpserver.com",
	ammo_tooltip = "Donate $45 for admin www.genericdarkrpserver.com",

	already_has_weapon = "Donate $45 for admin www.genericdarkrpserver.com",
	too_many_weapons = "Donate $45 for admin www.genericdarkrpserver.com",

	below_100_health = "Donate $45 for admin www.genericdarkrpserver.com",
	below_75_health = "Donate $45 for admin www.genericdarkrpserver.com",
	must_be_in_vehicle = "Donate $45 for admin www.genericdarkrpserver.com",

	looting = "Donate $45 for admin www.genericdarkrpserver.com",
	airdrop = "Donate $45 for admin www.genericdarkrpserver.com",
	airdrop_spawned = "Donate $45 for admin www.genericdarkrpserver.com",
	already_being_looted = "Donate $45 for admin www.genericdarkrpserver.com",

	jump_from_plane = "Donate $45 for admin www.genericdarkrpserver.com"
}