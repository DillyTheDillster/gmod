if SERVER then
	AddCSLuaFile()
end

SWEP.PrintName							= "Axe"	 
SWEP.Author									= "Models: The One Free-Man \nSWEP: ♕ Dilly ✄"
SWEP.Base										= "weapons_sck_base"
SWEP.Category								= "Weapons" 
SWEP.Slot										= 0
SWEP.SlotPos								= 1
SWEP.DrawAmmo								= false

SWEP.Spawnable							= true
SWEP.AdminSpawnable					= true

SWEP.HoldType 							= "melee2"
SWEP.ViewModel							= "models/c_minotaur_axe.mdl"	 
SWEP.WorldModel							= "models/freeman/minotaur_axe_prop.mdl"	
SWEP.DrawCrosshair					= false

SWEP.ViewModelFOV						= 120

SWEP.ViewModelFlip					= false
SWEP.UseHands 							= true

SWEP.Weight									= 1
SWEP.AutoSwitchTo						= true

SWEP.Primary.Damage					= 100
SWEP.Primary.ClipSize				= -1
SWEP.Primary.Delay					= 1
SWEP.Primary.DefaultClip		= 1
SWEP.Primary.Automatic			= true
SWEP.Primary.Ammo						= "none"

SWEP.Secondary.ClipSize			= -1
SWEP.Secondary.DefaultClip	= -1
SWEP.Secondary.Delay				= 1.5
SWEP.Secondary.Damage				= 100
SWEP.Secondary.Automatic		= false
SWEP.Secondary.Ammo					= "none"

SWEP.ShowWorldModel 		= false
SWEP.ShowViewModel 			= true

SWEP.NoSights = true
SWEP.IsSilent = true


SWEP.WElements = {
	["axe"] = { type = "Model", model = "models/freeman/minotaur_axe_prop.mdl", bone = "ValveBiped.Bip01_L_Hand", rel = "", pos = Vector(5, 3, 12.987), angle = Angle(-11, 5.8, 8), size = Vector(0.755, 0.755, 0.755), color = Color(255, 255, 255, 255), surpresslightning = false, material = "", skin = 0, bodygroup = {} }
}

SWEP.MissSound 							= Sound("weapons/knife/knife_slash1.wav")
SWEP.WallSound 							= Sound("npc/ministrider/flechette_flesh_impact1.wav")

/*---------------------------------------------------------
PrimaryAttack
---------------------------------------------------------*/
function SWEP:PrimaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Secondary.Delay)

	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	local rdm = math.random(1, 2)
		if rdm == 1 then
		self.Weapon:SendWeaponAnim(ACT_VM_HITRIGHT)
	else
		self.Weapon:SendWeaponAnim(ACT_VM_HITLEFT)
	end

	-- timer.Create("hitdelay"..self:EntIndex(), 0.2, 1, function() self:Attack() end)
	self:Attack()
end


/*---------------------------------------------------------
SecondaryAttack
---------------------------------------------------------*/
function SWEP:SecondaryAttack()
	self.Weapon:SetNextPrimaryFire(CurTime() + self.Primary.Delay)
	self.Weapon:SetNextSecondaryFire(CurTime() + self.Secondary.Delay)

	self.Owner:SetAnimation( PLAYER_ATTACK1 )
	self.Weapon:SendWeaponAnim(ACT_VM_HITCENTER)

	self:Attack()
end

/*---------------------------------------------------------
Reload
---------------------------------------------------------*/
local PushSound = {
	"physics/body/body_medium_impact_soft1.wav",
	"physics/body/body_medium_impact_soft2.wav",
	"physics/body/body_medium_impact_soft3.wav",
	"physics/body/body_medium_impact_soft4.wav",
	"physics/body/body_medium_impact_soft5.wav",
	"physics/body/body_medium_impact_soft6.wav",
	"physics/body/body_medium_impact_soft7.wav",
}

local push = {}

local cannotpush = {}

function SWEP:Reload()
	if not SERVER then return end
	-- self.Weapon:SendWeaponAnim(ACT_VM_DRAW)
	local ent = self.Owner:GetEyeTrace().Entity
	if not IsValid(ent) then return end
	if not ent:IsPlayer() then return end
	if ent:GetPos():DistToSqr(self.Owner:GetPos()) > 75*75 then return end
	
	self.Owner:EmitSound( PushSound[math.random(#PushSound) ], 50, 100 )
	local velAng = self.Owner:EyeAngles():Forward()
	velAng.z = 0.3
	ent:SetVelocity( velAng * 500 )
	ent:ViewPunch( Angle( math.random( -5, 5 ), math.random( -5, 5 ), 0 ) )
	push[self.Owner:UserID()] = true
	timer.Simple( 0.1, function() push[ self.Owner:SteamID64() ] = false end )
	cannotpush[ self.Owner:SteamID64() ] = true
	timer.Simple( 2, function() cannotpush[ self.Owner:SteamID64() ] = false end )
end

function SWEP:Attack()
	local tr = {}
	tr.start = self.Owner:GetShootPos()
	tr.endpos = self.Owner:GetShootPos() + ( self.Owner:GetAimVector() * 75 )
	tr.filter = self.Owner
	tr.mask = MASK_SHOT
	local trace = util.TraceLine( tr )

	if ( trace.Hit ) then
		bullet = {}
		bullet.Num    = 1
		bullet.Src    = self.Owner:GetShootPos()
		bullet.Dir    = self.Owner:GetAimVector()
		bullet.Spread = Vector(0, 0, 0)
		bullet.Tracer = 0
		bullet.Force  = 1
		bullet.Damage = self.Primary.Damage
		self.Owner:FireBullets(bullet)
		util.Decal("ManhackCut", trace.HitPos + trace.HitNormal, trace.HitPos - trace.HitNormal)
	else
		self.Weapon:EmitSound(self.MissSound,100,math.random(90,120))
	end

end